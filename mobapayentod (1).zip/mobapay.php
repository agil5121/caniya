<?php
include "config.php";
date_default_timezone_set('Asia/Jakarta');

function request($url, $data = null, $headers = null, $patch = null)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    if ($data):
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    endif;
    if ($patch):
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $patch);
    endif;
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if ($headers):
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    endif;
    curl_setopt($ch, CURLOPT_HEADER, 0);

    curl_setopt($ch, CURLOPT_ENCODING, "GZIP,DEFLATE");
    return curl_exec($ch);
}


function color($color, $text)
{
    $arrayColor = array(
        'grey' => '1;30',
        'red' => '1;31',
        'green' => '1;32',
        'yellow' => '1;33',
        'blue' => '1;34',
        'purple' => '1;35',
        'nevy' => '1;36',
        'white' => '1;0',
    );
    return "\033[" . $arrayColor[$color] . "m" . $text . "\033[0m";
}

function getStr($string, $start, $end)
{
    $string = " " . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) {
        return "";
    }
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

echo "Waktu Saat Ini: " . date("H:i") . PHP_EOL;
$now = date("H:i");

echo "Auto Create Order Pada - $target" . PHP_EOL;


$headersx = array();
$headersx[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0';
$headersx[] = 'X-Token: ' . $toket . '';
$urlinfo = "https://api.mobapay.com/account/info";
$info = request($urlinfo, null, $headersx);
$namanya = getStr($info, '"name":"', '"');
$emailnya = getStr($info, '"email":"', '"');

echo "Nama Mobapay: ";
echo color("green", "$namanya\n");
echo "Email Mobapay: ";
echo color("green", "$emailnya\n");

$a = true;
while ($a) {




    $now = date("H:i");
    if (date("H:i") == $target) {

        $headers = array();
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0';
        $headers[] = 'Accept: application/json, text/plain, */*';
        $headers[] = 'Accept-Language: en-US,en;q=0.5';
        $headers[] = 'Accept-Encoding: gzip, deflate, br';
        $headers[] = 'Content-Type: application/json;charset=UTF-8';
        $headers[] = 'X-Token: ' . $toket . '';
        $headers[] = 'Origin: https://mobapay.com';
        $headers[] = 'Dnt: 1';
        $headers[] = 'Sec-Gpc: 1';
        $headers[] = 'Connection: keep-alive';
        $headers[] = 'Referer: https://mobapay.com/';
        $headers[] = 'Sec-Fetch-Dest: empty';
        $headers[] = 'Sec-Fetch-Mode: cors';
        $headers[] = 'Sec-Fetch-Site: same-site';
        $headers[] = 'Te: trailers';

        // MEMBUAT ORDER
        echo "Order ID : ";
        orderid:
        $urlorder = "https://api.mobapay.com/pay/order";

	//EDIT ID ML DSNI
        $dataorder = "{\"app_id\":100000,\"user_id\":12619958,\"server_id\":2015,\"email\":\"$emailmobapay\",\"shop_id\":1001,\"amount_pay\":141000,\"currency_code\":\"IDR\",\"country_code\":\"ID\",\"goods_id\":48,\"num\":1,\"pay_channel_sub_id\":10099,\"price_pay\":141000,\"coupon_id\":\"\",\"lang\":\"id\",\"network\":\"\",\"net\":\"\",\"terminal_type\":\"WEB\"}";
        $order = request($urlorder, $dataorder, $headers);


        if (strpos($order, 'order_id') !== false) {
            $orderID = getStr($order, '"order_id":"', '"');
            $now = date("H:i:s");
            echo color("green", "$orderID [ $now ]\n");
        } else {
            echo "Error Get order_id\n";
            goto orderid;
        }

        //PAYMENTS
        //echo "URL Pay : ";
        $urlpay = "https://api.mobapay.com/pay/order/payment";
        $datapay = "{\"order_id\":\"$orderID\",\"return_url\":\"https://mobapay.com/order?order=$orderID\",\"network\":\"\",\"net\":\"\",\"terminal_type\":\"WEB\"}";
        $pay = request($urlpay, $datapay, $headers);
        $payurl = getStr($pay, '"payment_url":"', '"');
        $payurlfinal = str_replace("\u0026", "&", $payurl);
        $now = date("H:i:s");
        //echo color("green", "$payurlfinal [ $now ]\n");

        //AMBIL URL QR NYA
        //echo "URL QR : ";
        $urlqr = "$payurlfinal";
        $gasqr = request($urlqr, null, $headers);
        $txnID = getStr($pay, 'txn_id=', '"');
        $tidhash = getStr($gasqr, "&tidhash=", "'");
        $urlqr2 = "https://airtime.codapayments.com/airtime/epc-checkout?type=3&txn_id=$txnID&tidhash=$tidhash";
        $gasqr2 = request($urlqr2, null, $headers);
        $urlqr3 = "https://airtime.codapayments.com/airtime/epc-msisdn?TxnId=$txnID&browser_type=";
        $gasqr3 = request($urlqr3, null, $headers);
        $qrurl = getStr($gasqr3, "paymentCode': '", "'");
        $now = date("H:i:s");
        //echo color("green", "https://api.midtrans.com/v2/qris/$qrurl/qr-code [ $now ]\n");
        $imgqr = "https://api.midtrans.com/v2/qris/$qrurl/qr-code";

        //AMBIL DATA DARI QR
        scanqr:
        echo "SCAN QR : ";
        $url = "https://zxing.org/w/decode?u=$imgqr";
        $scanQR = request($url, $data = null, $headers = null);
        
    $headersqr = array();
    $headersqr[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0';
    $headersqr[] = 'Accept: */*';
    $headersqr[] = 'Accept-Language: en-US,en;q=0.5';
    $headersqr[] = 'Accept-Encoding: gzip, deflate, br';
    $headersqr[] = 'Content-Type: application/json';
    $headersqr[] = 'Referer: https://www.qrplus.com.br/';
    $headersqr[] = 'Origin: https://www.qrplus.com.br';
    $headersqr[] = 'Sec-Fetch-Dest: empty';
    $headersqr[] = 'Sec-Fetch-Mode: cors';
    $headersqr[] = 'Sec-Fetch-Site: same-site';
    $headersqr[] = 'Connection: keep-alive';
    $headersqr[] = 'Te: trailers';
        
        //$url = "https://decode.qrplus.com.br/api/Decode";
        //$dataqr = "{\"path\":\"$imgqr\"}";
        //$scanQR = request($url, $dataqr, $headersqr);
        //echo $scanQR;
        
        if (strpos($scanQR, 'COM.GO-JEK') !== false) {
            //$QRresult = getstr($scanQR, '"rawText":"', '"');
            $QRresult = getstr($scanQR, 'Raw text</td><td><pre>','<');
            file_put_contents("mobapay.txt", "$QRresult\n", FILE_APPEND);
            $now = date("H:i:s");
            echo color("green", "Success Scan QR  [ $now ]\n");
        } else {
            echo "Error Scan QR\n";
            goto scanqr;
        }


        $headersgp = array();
        $headersgp[] = "Pin: $pin";
        $headersgp[] = "X-Appversion: 4.46.2";
        $headersgp[] = "X-Appid: com.gojek.app";
        $headersgp[] = "Authorization: Bearer $accessToken";
        $headersgp[] = "X-Session-Id: $session";
        $headersgp[] = "X-Platform: iOS";
        $headersgp[] = "X-User-Locale: en_ID";
        $headersgp[] = "X-Uniqueid: $uniqueid";
        $headersgp[] = "Accept: application/json";
        $headersgp[] = "X-User-Type: customer";
        $headersgp[] = "X-Deviceos: iOS, 15.5";
        $headersgp[] = "X-Phonemake: Apple";
        $headersgp[] = "X-Phonemodel: Apple, iPhone 13 Pro";
        $headersgp[] = "Content-Type: application/json; charset=UTF-8";
        $headersgp[] = "Accept-Encoding: gzip, deflate";
        $headersgp[] = "User-Agent: okhttp/3.12.13";
        $headersgp[] = "Gojek-Country-Code: ID";


        echo "Check GOPAY Account : ";
        $url = "https://customer.gopayapi.com/v1/customer/payment-options?intent=DYNAMIC_QR";
        $getPaymentToken = request($url, null, $headersgp);
        if (strpos($getPaymentToken, '"success": true') !== false) {
            $paymentToken = getstr($getPaymentToken, '"token": "', '"');
            $now = date("H:i:s");
            echo color("green", "Ready [ $now ]\n");

        } else {
            echo "Error get Payment Token\n";
            exit();
        }

        $file = file_get_contents("mobapay.txt");
        $datax = explode("\n", $file);
        $count = count($datax);
        for ($a = 0; $a < $count; $a++) {
            $QRresult = $datax[$a];
            $url = "https://customer.gopayapi.com/v1/explore";
            $data = '{"data":"' . $QRresult . '","type":"QR_CODE"}';
            $getPaymentID = request($url, $data, $headersgp);
            if (strpos($getPaymentID, 'payment_id') !== false) {
                $paymentID = getstr($getPaymentID, '"payment_id": "', '"');
                $value = getstr($getPaymentID, 'value": "', '"');
                echo "$paymentID : ";
                //echo "$value : ";

            } else {
                echo "Error get Payment ID\n";
                //echo $getPaymentID;
                unlink('mobapay.txt');
                exit();

            }

            
            echo "Auto Pay Order Pada - $target2" . PHP_EOL;

            $b = true;
            while ($b) {


                
                if (date("H:i:s") == $target2) {

                    $url = "https://customer.gopayapi.com/v2/payments/$paymentID/capture";
                    $patch = '{
                        "additional_data": {
                          "merchant_order_id": "",
                          "customer_flow": "qr",
                          "aspiqr_information": {
                            "additional_data_national": "61051295062390703A015028'.$paymentID.'",
                            "merchant_city": "JAKARTA SELATAN",
                            "retrieval_reference_number": "",
                            "transaction_currency_code": "360",
                            "merchant_id": "M116638",
                            "purpose_of_transaction": "",
                            "store_label": "",
                            "terminal_label": "A01",
                            "bill_number": "",
                            "qr_transaction_type": "ON-US",
                            "loyalty_number": "",
                            "merchant_criteria": "UBE",
                            "reference_label": "",
                            "merchant_pan": "936009143959067664",
                            "additional_consumer_data_request": "",
                            "merchant_category_code": "7994",
                            "trx_fee_amount": 0,
                            "merchant_name": "PT Coda Indonesia - QRIS",
                            "issuer_name": "gopay",
                            "issuer_id": "93600914",
                            "acquirer_name": "gopay",
                            "country_code": "ID",
                            "acquirer_id": "93600914",
                            "customer_label": "",
                            "postal_code": "12950",
                            "mobile_number": ""
                          }
                        },
                        "applied_promo_code": [
                          "NO_PROMO_APPLIED"
                        ],
                        "channel_type": "DYNAMIC_QR",
                        "checksum": {
                          "version": "3",
                          "value": "'.$value.'"
                        },
                        "metadata": {
                          "merchant_cross_reference_id": "d8e0350d-4810-4733-9ebd-75e798c307dc",
                          "payment_widget_intent": "DYNAMIC_QR",
                          "aspi_qr_acquirer": "gopay",
                          "aspi_qr_data": "{\"amount\":1410,\"postal_code\":\"12950\",\"merchant_city\":\"JAKARTA SELATAN\",\"merchant_id\":\"G959067664\",\"merchant_criteria\":\"UBE\",\"merchant_pan\":\"936009143959067664\",\"country_code\":\"ID\",\"transaction_currency_code\":\"360\",\"additional_data_national\":\"61051295062390703A015028'.$paymentID.'\",\"additional_data\":{\"store_label\":null,\"mobile_number\":null,\"reference_label\":null,\"purpose_of_transaction\":null,\"customer_label\":null,\"terminal_label\":\"A01\",\"bill_number\":null,\"custom_50\":\"'.$paymentID.'\",\"additional_consumer_data_request\":null,\"loyalty_number\":null},\"merchant_category_code\":\"7994\",\"merchant_name\":\"PT Coda Indonesia - QRIS\",\"trx_fee_amount\":0,\"acquirer_id\":\"93600914\"}",
                          "checksum": "{\"version\":\"3\",\"value\":\"'.$value.'\"}",
                          "external_merchant_name": "Codashop",
                          "customer_flow": "qr",
                          "aspi_qr_transaction_type": "ON-US",
                          "aspi_qr_issuer": "gopay"
                        },
                        "order_signature": {
                          "reason": "",
                          "partner_id": "",
                          "partner_name": "",
                          "source": "",
                          "channel_type": "",
                          "transaction_type": "",
                          "customer_fulfillment_type": ""
                        },
                        "payment_token": "'.$paymentToken.'"
                      }';
                    $pay = request($url, null, $headersgp, $patch);
                    if (strpos($pay, '"PAID"') !== false) {
                        $now = date("H:i:s");
                        echo color("green", "Success Pay [ $now ]\n");
                        unlink('mobapay.txt');
                        
                        sleep(30);
                        
                        $urlcekvoc = "https://api.mobapay.com/account/coupon_list?country=ID&language=id";
                        $cekvoc = request($urlcekvoc, null, $headersx);
                        //echo $cekvoc;
                        $hasil = json_decode($cekvoc);
                        $totalvoc = count($hasil->data->unused);
                        echo "Total Voucher Kamu: ";
                        $now = date("H:i:s");
                        echo color("green", "$totalvoc [ $now ]\n");                     
                        
                        $a = false;
                        $b = false;
                        exit();
                    } else {
                        echo color("red", "Error Pay\n");
                        echo $pay;
                        unlink('mobapay.txt');
                        $a = false;
                        $b = false;
                        exit();
                    }
                } else {
                    //echo "belum eksekusi pay";  
                }
            }
        }
        $a = false;
    } else {
        //echo "belum eksekusi";      
    }
}
?>
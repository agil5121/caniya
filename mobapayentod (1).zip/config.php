<?php 


$pin = "301000"; //Pin GOJEK


///AUTO EDIT BY LOGIN.PHP
$accessToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9xxxxxxxxxxx";
$session = "ab8d4ed5-2c98-456b-aaaa-xxxxxxxxx";
$uniqueid = "d4f0dda5-4061-4f98-af15-xxxxx";

//EDIT MANUAL UNTUK FIRST RUN toket mobapay dan email mobapay

$toket = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xxxxxx";
$emailmobapay = "jembot@gmail.com";

//EDIT WAKTU EKSEKUSI ORDER DAN AUTOPAY QRIS
$target = '11:52'; //waktu eksekusi membuat order
$target2 = '11:59:58'; //waktu eksekusi autopay

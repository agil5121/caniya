#!/bin/sh
while :
do
    php ref.php
    sleep 60
done
